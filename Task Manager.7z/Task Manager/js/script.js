var taskList = {
    tasks:[],

    addTask : function(taskDetails) {
        this.tasks.push({
            taskDetails : taskDetails
        });
    },
    deleteTasks : function(position){
        this.tasks.splice(position,1);
    },
    deleteAllTasks : function(){
        this.tasks = [];
    }
    
}

var controller = {

    addTask:function() {
        
        var titleInput = document.getElementById('titleInput');
        var dueDateInput =  document.getElementById("dueDateInput");
        var taskDetails = {
            title : titleInput.value,
            dueDate : dueDateInput.value,
            status : false
        };
        taskList.addTask(taskDetails);
        titleInput.value='';
        dueDateInput.value=''; 
        view.displayTasks();
    },
    delete : function () {
        var checkboxes = document.getElementsByName("checkbox");
        for (index = checkboxes.length-1 ; index>=0 ; index--){
            if(checkboxes[index].checked){
               this.deleteByIndex(index);
            }}
           view.displayTasks();
       },
       
       deleteByIndex : function (index){
           console.log(index);
           taskList.tasks.splice(index,1);
           console.log(taskList.tasks[index]);
       },
       
       changeStatus : function (){
       var checkboxes = document.getElementsByName("checkbox");
        for (index = checkboxes.length-1 ; index>=0 ; index--){
            if(checkboxes[index].checked){
               this.changeStatusByIndex(index);
            }}
           view.displayTasks();
       },
       
       changeStatusByIndex : function (index){
           console.log(index);
           taskList.tasks[index].taskDetails.status = ! taskList.tasks[index].taskDetails.status;
           console.log(taskList.tasks[index]);
       },
       calculateDate : function(dueDate){
            var today = new Date();
            console.log(dueDate.value);
            var dueDate = new Date("dueDate");
            console.log("Today's date "+today.getDate());
            console.log("Due Date "+dueDate);
            // var timeDiff = Math.abs(dueDate.getTime() - today.getTime());
            // var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
            // console.log("Difference in days:"+diffDays);
            //console.log(today);
       },
       filter : function() {
            var filterCriteria = document.getElementById("filterId").value;
            document.getElementById("filterId").value = '';
            var tasksInProgress = taskList.tasks;
            if(filterCriteria==="In Progress"){
                for(let i = 0; i<taskList.tasks.length;i++){
                    
                    tasksInProgress.push();
                }
        }
       }
}

var view = {

    displayTasks:function() {
        var taskTable = document.querySelector("table");
        taskTable.innerHTML = "";

        var checkBoxTH = document.createElement("th");
            checkBoxTH.appendChild(this.createCheckBox());

        var titleTH = document.createElement("th");
            titleTH.textContent = "Title";
        var dueDateTH = document.createElement("th");
            dueDateTH.textContent = "Due Date";
        var statusTH = document.createElement("th");
            statusTH.textContent = "Status";
        
        taskTable.appendChild(checkBoxTH);
        taskTable.appendChild(titleTH);
        taskTable.appendChild(dueDateTH);
        taskTable.appendChild(statusTH);

        for(let i=0;i<taskList.tasks.length;i++){
        
            var checkBox = this.createCheckBox();
                checkBox.id = i;
                checkBox.name = "checkbox";

            var task = taskList.tasks[i].taskDetails;

            var taskTr = document.createElement("tr");
            taskTr.id = i;

            var titleTd = document.createElement("td");
            titleTd.textContent = task.title;

            var dueDateTd = document.createElement("td");
            controller.calculateDate(task.dueDate);
            dueDateTd.textContent = task.dueDate;

            var statusTd = document.createElement("td");
            if(task.status)
                statusTd.textContent = "completed";
            else
                statusTd.textContent = "In Progress";

            taskTr.appendChild(checkBox);
            taskTr.appendChild(titleTd);
            taskTr.appendChild(dueDateTd);
            taskTr.appendChild(statusTd);

            taskTable.appendChild(taskTr);
           
        }
    },
    createCheckBox : function(){
        var checkBox = document.createElement('input');
        checkBox.type = 'checkbox';
        return checkBox;
    }
}


